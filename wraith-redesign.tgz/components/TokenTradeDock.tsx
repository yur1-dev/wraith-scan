"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useConnection } from "@solana/wallet-adapter-react";
import { PublicKey, VersionedTransaction } from "@solana/web3.js";
import { usePrivy } from "@privy-io/react-auth";
import { useSignTransaction, useWallets as useSolanaWallets } from "@privy-io/react-auth/solana";
import { Copy, ExternalLink, LoaderCircle, Wallet } from "lucide-react";
import type { MemeTrend } from "@/app/app/page";
import { useToast } from "@/components/Toast";
import { executeQuickBuy, executeQuickSell, explorerUrl, SwapError, SOL_MINT } from "@/lib/jupiterSwap";
import { PRIVY_WALLETS_ENABLED } from "@/lib/privyConfig";
import { formatCurrency, isDisplayCurrency, type DisplayCurrency } from "@/lib/currencies";

const MONO = { fontFamily: "var(--font-mono), 'IBM Plex Mono', monospace" };
const CASH_PRESETS_USD = [5, 10, 25, 50];
const SELL_PRESETS = [25, 50, 100];

type Props = { meme: MemeTrend | null };
type Mode = "buy" | "sell";
type MarketSnapshot = {
  name: string | null;
  symbol: string | null;
  description: string | null;
  marketCap: number | null;
  liquidity: number | null;
  volume24h: number | null;
  buys24h: number | null;
  sells24h: number | null;
  priceChange: { m5: number | null; h1: number | null; h6: number | null; h24: number | null };
  dexId: string | null;
  pairCreatedAt: number | null;
  website: string | null;
  twitter: string | null;
  telegram: string | null;
};

function formatUsd(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "—";
  if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
  if (value >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
  return `$${value.toFixed(2)}`;
}

function readMetric(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function readText(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value : null;
}

function formatChange(value: number | null): string {
  if (value === null) return "-";
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function formatAge(timestamp: number | null): string {
  if (timestamp === null || timestamp <= 0) return "-";
  const ageMs = Date.now() - timestamp;
  if (ageMs < 0) return "-";
  const minutes = Math.floor(ageMs / 60_000);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export default function TokenTradeDock({ meme }: Props) {
  if (!PRIVY_WALLETS_ENABLED) return <UnconfiguredDock meme={meme} />;
  return <EmbeddedTradeDock meme={meme} />;
}

function UnconfiguredDock({ meme }: Props) {
  return (
    <DockFrame>
      <div style={{ padding: 20, color: "var(--text-muted)", fontSize: 12, lineHeight: 1.6 }}>
        Embedded wallet trading is not configured for this deployment.
      </div>
    </DockFrame>
  );
}

function DockFrame({ children }: { children: ReactNode }) {
  return (
    <aside style={{ height: "100%", minHeight: 0, overflowY: "auto", background: "var(--bg)", color: "var(--text)", borderLeft: "1px solid var(--border)", ...MONO }}>
      {children}
    </aside>
  );
}

function EmbeddedTradeDock({ meme }: Props) {
  const mint = meme?.contractAddress || "";
  const symbol = (meme?.keyword || "TOKEN").toUpperCase();
  const { user } = usePrivy();
  const { wallets } = useSolanaWallets();
  const { signTransaction } = useSignTransaction();
  const { connection } = useConnection();
  const { push } = useToast();
  const [mode, setMode] = useState<Mode>("buy");
  const [amountCash, setAmountCash] = useState("10");
  const [sellPercent, setSellPercent] = useState(100);
  const [tokenBalance, setTokenBalance] = useState<{ amount: string; quantity: number; decimals: number } | null>(null);
  const [displayCurrency, setDisplayCurrency] = useState<DisplayCurrency>("USD");
  const [currencyRate, setCurrencyRate] = useState<number | null>(1);
  const [tokenUsd, setTokenUsd] = useState<number | null>(null);
  const [marketSnapshot, setMarketSnapshot] = useState<MarketSnapshot | null>(null);
  const [solUsd, setSolUsd] = useState<number | null>(null);
  const [cashBalance, setCashBalance] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const previousCurrencyRate = useRef<number | null>(1);

  const embeddedAccount = user?.linkedAccounts.find((account) =>
    account.type === "wallet" && account.chainType === "solana" && account.walletClientType === "privy",
  );
  const embeddedWallet = embeddedAccount?.type === "wallet"
    ? wallets.find((wallet) => wallet.address === embeddedAccount.address)
    : undefined;
  const embeddedAddress = embeddedAccount?.type === "wallet" ? embeddedAccount.address : null;
  const publicKey = useMemo(
    () => embeddedAddress ? new PublicKey(embeddedAddress) : null,
    [embeddedAddress],
  );
  const shortAddress = embeddedAddress
    ? `${embeddedAddress.slice(0, 5)}...${embeddedAddress.slice(-4)}`
    : "Wallet not ready";
  const amountUsd = currencyRate && currencyRate > 0
    ? Number(amountCash) / currencyRate
    : 0;
  const amountSol = solUsd && solUsd > 0 ? amountUsd / solUsd : 0;
  const tradeDisabledReason = busy
    ? "Waiting for wallet confirmation..."
    : !mint
      ? "Token address is unavailable."
      : !embeddedWallet || !publicKey
        ? "Embedded wallet is still loading."
        : mode === "buy"
          ? currencyRate === null
            ? "Loading exchange rate..."
            : !Number.isFinite(amountUsd) || amountUsd <= 0
              ? `Enter a ${displayCurrency} amount greater than zero.`
              : solUsd === null || cashBalance === null
                ? "Loading your SOL balance and price..."
                : amountSol + 0.01 > cashBalance
                  ? "Not enough SOL for this buy and network fees."
                  : null
          : !tokenBalance
            ? "Loading your token balance..."
            : tokenBalance.quantity <= 0
              ? `No ${symbol} available to sell.`
              : null;
  const tradeDisabled = tradeDisabledReason !== null;
  const buyCount = marketSnapshot?.buys24h;
  const sellCount = marketSnapshot?.sells24h;
  const activityComplete = buyCount !== null && buyCount !== undefined && sellCount !== null && sellCount !== undefined;
  const activityTotal = (buyCount ?? 0) + (sellCount ?? 0);
  const buyShare = activityComplete && activityTotal > 0 ? (buyCount / activityTotal) * 100 : 0;

  useEffect(() => {
    const savedCurrency = localStorage.getItem("wraith_display_currency_v1");
    if (isDisplayCurrency(savedCurrency)) setDisplayCurrency(savedCurrency);
    const onCurrency = (event: Event) => {
      const nextCurrency = (event as CustomEvent<DisplayCurrency>).detail;
      if (isDisplayCurrency(nextCurrency)) setDisplayCurrency(nextCurrency);
    };
    window.addEventListener("wraith:currency-sync", onCurrency);
    return () => window.removeEventListener("wraith:currency-sync", onCurrency);
  }, []);

  useEffect(() => {
    let active = true;
    if (displayCurrency === "USD") {
      setCurrencyRate(1);
      return () => { active = false; };
    }
    setCurrencyRate(null);
    fetch(`/api/fx?currency=${displayCurrency}`, { cache: "no-store" })
      .then((response) => response.json())
      .then((payload: { rate?: unknown }) => {
        if (active && typeof payload.rate === "number" && Number.isFinite(payload.rate) && payload.rate > 0) setCurrencyRate(payload.rate);
      })
      .catch((error) => {
        console.error("[trade currency rate]", error);
        if (active) setCurrencyRate(null);
      });
    return () => { active = false; };
  }, [displayCurrency]);

  useEffect(() => {
    if (currencyRate === null) return;
    const previousRate = previousCurrencyRate.current;
    if (previousRate !== null && previousRate !== currencyRate) {
      setAmountCash((current) => (Number(current) / previousRate * currencyRate).toFixed(2));
    }
    previousCurrencyRate.current = currencyRate;
  }, [currencyRate]);

  useEffect(() => {
    let active = true;
    setTokenUsd(null);
    setMarketSnapshot(null);
    setSolUsd(null);
    const refreshPrices = async () => {
      try {
        const solResponse = await fetch(`/api/price?ids=${SOL_MINT}`, { cache: "no-store" });
        const solPayload = await solResponse.json();
        const currentSolUsd = Number(solPayload?.data?.[SOL_MINT]?.price ?? solPayload?.[SOL_MINT]?.usdPrice ?? solPayload?.[SOL_MINT]?.price);
        if (active && Number.isFinite(currentSolUsd) && currentSolUsd > 0) setSolUsd(currentSolUsd);
        const tokenResponse = mint ? await fetch(`/api/token-price?mint=${encodeURIComponent(mint)}`, { cache: "no-store" }) : null;
        const tokenPayload = tokenResponse?.ok ? await tokenResponse.json() : null;
        if (!active) return;
        let priceUsd = Number(tokenPayload?.priceUsd);
        if (tokenPayload) {
          const priceChange = tokenPayload.priceChange;
          setMarketSnapshot({
            name: readText(tokenPayload.name),
            symbol: readText(tokenPayload.symbol),
            description: readText(tokenPayload.description),
            marketCap: readMetric(tokenPayload.marketCap),
            liquidity: readMetric(tokenPayload.liquidity),
            volume24h: readMetric(tokenPayload.volume24h),
            buys24h: readMetric(tokenPayload.buys24h),
            sells24h: readMetric(tokenPayload.sells24h),
            priceChange: {
              m5: readMetric(priceChange?.m5),
              h1: readMetric(priceChange?.h1),
              h6: readMetric(priceChange?.h6),
              h24: readMetric(priceChange?.h24),
            },
            dexId: readText(tokenPayload.dexId),
            pairCreatedAt: readMetric(tokenPayload.pairCreatedAt),
            website: readText(tokenPayload.website),
            twitter: readText(tokenPayload.twitter),
            telegram: readText(tokenPayload.telegram),
          });
        }
        if ((!Number.isFinite(priceUsd) || priceUsd <= 0) && mint) {
          const fallbackResponse = await fetch(`/api/price?ids=${encodeURIComponent(mint)}`, { cache: "no-store" });
          const fallbackPayload = await fallbackResponse.json();
          priceUsd = Number(fallbackPayload?.[mint]?.usdPrice ?? fallbackPayload?.[mint]?.price);
        }
        if (active && Number.isFinite(priceUsd) && priceUsd > 0) setTokenUsd(priceUsd);
      } catch (error) {
        console.error("[trade market prices]", error);
      }
    };
    void refreshPrices();
    const timer = window.setInterval(() => void refreshPrices(), 5_000);
    return () => { active = false; window.clearInterval(timer); };
  }, [mint]);

  const refreshTokenBalance = useCallback(async () => {
    if (!mint || !publicKey) { setTokenBalance(null); return; }
    try {
      const accounts = await connection.getParsedTokenAccountsByOwner(publicKey, { mint: new PublicKey(mint) });
      const value = accounts.value.reduce((sum, account) => {
        const info = account.account.data.parsed.info.tokenAmount;
        return { raw: sum.raw + BigInt(info.amount), decimals: info.decimals };
      }, { raw: BigInt(0), decimals: 0 });
      const quantity = Number(value.raw) / 10 ** value.decimals;
      setTokenBalance({ amount: quantity.toLocaleString(undefined, { maximumFractionDigits: 4 }), quantity, decimals: value.decimals });
    } catch { setTokenBalance(null); }
  }, [connection, mint, publicKey]);

  const refreshCashBalance = useCallback(async () => {
    if (!publicKey) { setCashBalance(null); return; }
    try {
      const lamports = await connection.getBalance(publicKey, "confirmed");
      setCashBalance(lamports / 1e9);
    } catch {
      setCashBalance(null);
    }
  }, [connection, publicKey]);

  useEffect(() => {
    void refreshTokenBalance();
    void refreshCashBalance();
    const timer = window.setInterval(() => void refreshTokenBalance(), 10_000);
    const cashTimer = window.setInterval(() => void refreshCashBalance(), 15_000);
    return () => { window.clearInterval(timer); window.clearInterval(cashTimer); };
  }, [refreshCashBalance, refreshTokenBalance]);

  const trade = async () => {
    if (!mint || !embeddedWallet || !publicKey || busy) return;
    if (mode === "buy" && (!Number.isFinite(amountUsd) || amountUsd <= 0)) {
      push(`Enter a ${displayCurrency} amount greater than zero.`, "warning");
      return;
    }
    setBusy(true);
    const wallet = {
      publicKey,
      signTransaction: async (transaction: VersionedTransaction) => {
        const result = await signTransaction({ transaction: transaction.serialize(), wallet: embeddedWallet, chain: "solana:mainnet" });
        return VersionedTransaction.deserialize(result.signedTransaction);
      },
    };
    try {
      const result = mode === "buy"
        ? await executeQuickBuy(mint, amountSol, wallet, connection)
        : await executeQuickSell(mint, sellPercent, wallet, connection);
      push(`${mode === "buy" ? "Bought" : "Sold"} ${symbol}`, "success", {
        actionLabel: "VIEW TX",
        onAction: () => window.open(explorerUrl(result.signature), "_blank", "noopener,noreferrer"),
        timeoutMs: 7000,
      });
      await refreshTokenBalance();
      await refreshCashBalance();
    } catch (error) {
      const message = error instanceof SwapError ? error.message : "Trade failed. Try again.";
      push(message, error instanceof SwapError && error.code === "INSUFFICIENT_SOL" ? "error" : "warning");
    } finally { setBusy(false); }
  };

  const copyMint = async () => {
    try {
      await navigator.clipboard.writeText(mint);
      push("Contract address copied", "success");
    } catch (error) {
      console.error("[copy token address]", error);
      push("Could not copy contract address", "warning");
    }
  };

  return (
    <DockFrame>
      <div style={{ padding: 16 }}>
        <div style={{ display: "flex", gap: 6, marginBottom: 14 }}>
          {(["buy", "sell"] as const).map((tab) => (
            <button key={tab} type="button" onClick={() => setMode(tab)} style={{ flex: 1, border: `1px solid ${mode === tab ? (tab === "buy" ? "#267454" : "#89463e") : "var(--border)"}`, background: mode === tab ? (tab === "buy" ? "#14241d" : "#261917") : "var(--surface)", color: mode === tab ? (tab === "buy" ? "#55cf91" : "#e58d80") : "var(--text-muted)", borderRadius: 9, padding: "11px 8px", textTransform: "capitalize", fontWeight: 750, cursor: "pointer" }}>{tab}</button>
          ))}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 9, padding: "10px 12px", marginBottom: 12, border: "1px solid var(--border)", borderRadius: 10, color: "var(--text-muted)", fontSize: 11 }}>
          <Wallet size={14} color="var(--orange)" />
          <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis" }}>{shortAddress}</span>
          <span style={{ color: embeddedWallet ? "#37d58a" : "#ffba55" }}>{embeddedWallet ? "READY" : "SETUP"}</span>
        </div>

        {mode === "buy" ? (
          <>
            <div style={{ display: "flex", justifyContent: "space-between", margin: "0 1px 10px", color: "var(--text-muted)", fontSize: 11 }}>
              <span>Cash value available</span>
              <strong style={{ color: "var(--text)" }}>{cashBalance === null || solUsd === null || currencyRate === null ? "Loading..." : formatCurrency(cashBalance * solUsd * currencyRate, displayCurrency)}</strong>
            </div>
            <label style={{ display: "block", color: "var(--text-muted)", fontSize: 10, marginBottom: 6 }}>AMOUNT IN {displayCurrency}</label>
            <input aria-label={`Buy amount in ${displayCurrency}`} inputMode="decimal" value={amountCash} onChange={(event) => setAmountCash(event.target.value)} style={{ width: "100%", height: 54, padding: "0 14px", color: "var(--text)", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 10, outlineColor: "var(--orange)", fontSize: 20, fontWeight: 700, ...MONO }} />
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginTop: 8 }}>
              {CASH_PRESETS_USD.map((presetUsd) => {
                const cashValue = currencyRate !== null ? presetUsd * currencyRate : 0;
                return <button type="button" key={presetUsd} disabled={currencyRate === null} onClick={() => setAmountCash(cashValue.toFixed(2))} style={{ padding: "8px 2px", border: `1px solid ${Math.abs(Number(amountCash) - cashValue) < 0.005 ? "var(--orange)" : "var(--border)"}`, borderRadius: 8, color: Math.abs(Number(amountCash) - cashValue) < 0.005 ? "var(--orange-hot)" : "var(--text-muted)", background: "var(--surface)", cursor: "pointer", fontSize: 11 }}>{currencyRate !== null ? formatCurrency(cashValue, displayCurrency) : "—"}</button>;
              })}
            </div>
          </>
        ) : (
          <>
            <div style={{ color: "var(--text-muted)", fontSize: 10, marginBottom: 6 }}>TOKEN BALANCE</div>
            <div style={{ padding: "15px 14px", marginBottom: 8, border: "1px solid var(--border)", borderRadius: 10, background: "var(--surface)", fontSize: 18, fontWeight: 700 }}>{tokenBalance?.amount ?? "Loading..."}<span style={{ marginLeft: 7, color: "var(--text-muted)", fontSize: 11 }}>{symbol}</span>{tokenBalance && tokenUsd !== null && currencyRate !== null && <small style={{ display: "block", marginTop: 8, color: "var(--text-muted)", fontSize: 12, fontWeight: 500 }}>{formatCurrency(tokenBalance.quantity * tokenUsd * currencyRate, displayCurrency)}</small>}</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6 }}>
              {SELL_PRESETS.map((preset) => <button type="button" key={preset} onClick={() => setSellPercent(preset)} style={{ padding: "9px 4px", border: `1px solid ${sellPercent === preset ? "#a9564c" : "var(--border)"}`, borderRadius: 8, color: sellPercent === preset ? "#e58d80" : "var(--text-muted)", background: "var(--surface)", cursor: "pointer", fontSize: 11 }}>{preset === 100 ? "Max" : `${preset}%`}</button>)}
            </div>
          </>
        )}

        <button type="button" onClick={() => void trade()} disabled={tradeDisabled} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, width: "100%", minHeight: 48, marginTop: 14, border: 0, borderRadius: 10, color: "#fff", background: mode === "buy" ? "#d96d3c" : "#a95047", fontSize: 14, fontWeight: 800, cursor: busy ? "wait" : "pointer", opacity: tradeDisabled ? .68 : 1 }}>
          {busy ? <LoaderCircle size={16} className="animate-spin" /> : null}
          {busy ? "Confirm in wallet?" : `${mode === "buy" ? "Buy" : `Sell ${sellPercent === 100 ? "max" : `${sellPercent}%`}`} ${symbol}`}
        </button>
        {tradeDisabledReason && <p role="status" style={{ margin: "8px 2px 0", color: "var(--text-muted)", fontSize: 10, lineHeight: 1.5 }}>{tradeDisabledReason}</p>}
        <p style={{ margin: "10px 2px 0", color: "var(--text-dim)", fontSize: 10, lineHeight: 1.55 }}>Cash estimates use your selected currency. Buys spend SOL and sells return SOL; approve each transaction in your wallet.</p>
      </div>

      <div style={{ padding: "15px 16px", borderTop: "1px solid var(--border)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <strong style={{ fontSize: 13 }}>Your position</strong>
          <button type="button" onClick={() => void refreshTokenBalance()} title="Refresh token balance" style={{ border: 0, background: "transparent", color: "var(--text-muted)", cursor: "pointer", fontSize: 11 }}>Refresh</button>
        </div>
        {tokenBalance?.amount && tokenBalance.amount !== "0" ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 5, padding: "12px", borderRadius: 9, background: "var(--surface)", color: "var(--text)", fontSize: 12 }}><strong style={{ color: "var(--text)", fontSize: 18 }}>{tokenBalance && tokenUsd !== null && currencyRate !== null ? formatCurrency(tokenBalance.quantity * tokenUsd * currencyRate, displayCurrency) : "Price updating…"}</strong><span>{tokenBalance.amount} {symbol}</span></div>
        ) : <div style={{ padding: "18px 10px", borderRadius: 9, background: "var(--surface)", textAlign: "center", color: "var(--text-muted)", fontSize: 11 }}>No {symbol} in this wallet yet</div>}
      </div>

    </DockFrame>
  );
}
