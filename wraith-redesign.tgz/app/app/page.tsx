"use client";

import { useCallback, useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import { cacheTokenNav } from "@/lib/tokenNav";
import { ToastProvider } from "@/components/Toast";

const Header = dynamic(() => import("@/components/Header"), { ssr: false });
const TokenBoard = dynamic(() => import("@/components/TokenBoard"), { ssr: false });
const MemeScanner = dynamic(() => import("@/components/MemeScanner"), { ssr: false });
const WinsPanel = dynamic(() => import("@/components/WinsPanel"), { ssr: false });
const LiveSignalsBar = dynamic(() => import("@/components/LiveSignalsBar"), { ssr: false });

// Shared across the app (scanner, wins, favorites, token navigation).
export interface MemeTrend {
  keyword: string;
  score: number;
  posts: number;
  source: string;
  hasTicker?: boolean;
  crossPlatforms?: number;
  isNewCoin?: boolean;
  ageLabel?: string;
  mcap?: number;
  liquidity?: number;
  volume?: number;
  tokenImageUrl?: string;
  platforms?: string[];
  contractAddress?: string;
  celebMention?: string;
  aiContext?: string;
}

type View = "market" | "scanner" | "wins";
const VIEWS: { key: View; label: string; hint: string }[] = [
  { key: "market", label: "Market", hint: "Live Solana tokens" },
  { key: "scanner", label: "Scanner", hint: "Viral meme → token signals" },
  { key: "wins", label: "Wins", hint: "Tracked winners" },
];

export default function Home() {
  const router = useRouter();
  const [view, setView] = useState<View>("market");
  const [selected, setSelected] = useState<MemeTrend | null>(null);

  useEffect(() => {
    try {
      const v = localStorage.getItem("wraith_home_view");
      if (v === "market" || v === "scanner" || v === "wins") setView(v);
    } catch {
      /* storage unavailable */
    }
  }, []);

  const changeView = useCallback((next: View) => {
    setView(next);
    try {
      localStorage.setItem("wraith_home_view", next);
    } catch {
      /* ignore */
    }
  }, []);

  const handleSelectMeme = useCallback(
    (meme: MemeTrend) => {
      setSelected(meme);
      if (!meme.contractAddress) return;
      cacheTokenNav(meme);
      router.push(`/app/token/${encodeURIComponent(meme.contractAddress)}`);
    },
    [router],
  );

  return (
    <ToastProvider>
    <div className="wraith-dashboard wx-page">
      <Header onSelectMeme={handleSelectMeme} />

      <nav className="wx-subnav" aria-label="Discover sections">
        <div className="wx-subnav-inner">
          {VIEWS.map((v) => (
            <button key={v.key} type="button" className={view === v.key ? "on" : ""} aria-current={view === v.key ? "page" : undefined} onClick={() => changeView(v.key)}>
              {v.label}
            </button>
          ))}
          <span className="wx-subnav-hint">{VIEWS.find((v) => v.key === view)?.hint}</span>
        </div>
      </nav>

      <main className="wx-main">
        {view === "market" && <TokenBoard onSelectMeme={handleSelectMeme} />}

        {view === "scanner" && (
          <div className="wx-scanner-layout">
            <aside className="wx-scanner-rail">
              <LiveSignalsBar onSelectMeme={handleSelectMeme} layout="rail" />
            </aside>
            <div className="wx-scanner-main">
              <MemeScanner onSelectMeme={handleSelectMeme} selectedMeme={selected} />
            </div>
          </div>
        )}

        {view === "wins" && (
          <div className="wx-wins" style={{ containerType: "inline-size", containerName: "wins-rail" }}>
            <WinsPanel onSelectMeme={handleSelectMeme} />
          </div>
        )}
      </main>
    </div>
    </ToastProvider>
  );
}
