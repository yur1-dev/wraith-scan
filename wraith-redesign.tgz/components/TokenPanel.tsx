"use client";

// components/TokenPanel.tsx
// Center column of the token page: identity + live stats + chart + activity.
// Rebuilt around two server endpoints (/api/token-price, /api/token-chart) so
// every number on screen comes from one consistent snapshot.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Bookmark, Check, Copy, ExternalLink, Globe, Link2, Send } from "lucide-react";
import type { MemeTrend } from "@/app/app/page";
import TokenChart from "@/components/TokenChart";
import { TokenDetailTabs, type IntelLink, type TradeRow } from "@/components/TokenDetailTabs";
import { TokenIcon } from "@/components/TokenIcon";
import { readTokenFavorites, toggleTokenFavorite, TOKEN_FAVORITES_EVENT } from "@/lib/tokenFavorites";
import { changeColor, fmtAge, fmtCount, fmtPct, fmtPrice, fmtUsd, shortAddr } from "@/lib/market";

interface Windowed<T> {
  m5: T;
  h1: T;
  h6: T;
  h24: T;
}
interface Snapshot {
  mint: string;
  priceUsd: number;
  name: string | null;
  symbol: string | null;
  description: string | null;
  marketCap: number | null;
  liquidity: number | null;
  volume24h: number | null;
  priceChange: Windowed<number | null>;
  dexId: string | null;
  pairCreatedAt: number | null;
  website: string | null;
  twitter: string | null;
  telegram: string | null;
  imageUrl: string | null;
  pairAddress: string | null;
  supply: number | null;
  volume: Windowed<number>;
  txns: Windowed<{ buys: number; sells: number }>;
  onCurve: boolean;
  graduated: boolean;
  curveProgress: number | null;
  stale?: boolean;
}
interface ApiTrade {
  id: string;
  ts: number;
  side: "buy" | "sell";
  usd: number;
  tokens: number;
  priceUsd: number;
  wallet: string;
}
interface Analysis {
  links?: IntelLink[];
  predictionReason?: string;
  safetyScore?: number;
  safetyBreakdown?: { label: string; pass: boolean; detail: string }[];
}

function XGlyph({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

type SnapState = "loading" | "ready" | "missing" | "error";

export default function TokenPanel({ selectedMeme }: { selectedMeme: MemeTrend | null }) {
  const mint = selectedMeme?.contractAddress ?? "";
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [snapState, setSnapState] = useState<SnapState>("loading");
  const [trades, setTrades] = useState<ApiTrade[]>([]);
  const [holders, setHolders] = useState<number | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState<"ca" | "link" | null>(null);
  const [flash, setFlash] = useState<{ dir: "up" | "down"; n: number } | null>(null);
  const prevPrice = useRef<number | null>(null);

  // ── live snapshot (price, mcap, volume, txns, socials) ────────────────
  useEffect(() => {
    if (!mint) return;
    setSnap(null);
    setSnapState("loading");
    setFlash(null);
    prevPrice.current = null;
    let alive = true;
    let timer: ReturnType<typeof setTimeout>;
    const run = async () => {
      try {
        const res = await fetch(`/api/token-price?mint=${encodeURIComponent(mint)}`, {
          cache: "no-store",
          signal: AbortSignal.timeout(10_000),
        });
        if (!alive) return;
        if (res.ok) {
          const data: Snapshot = await res.json();
          if (!alive) return;
          setSnap(data);
          setSnapState("ready");
        } else if (res.status === 404) {
          setSnapState((s) => (s === "ready" ? s : "missing"));
        } else {
          throw new Error(String(res.status));
        }
      } catch {
        if (alive) setSnapState((s) => (s === "ready" ? s : "error"));
      }
      if (alive) timer = setTimeout(run, document.hidden ? 15_000 : 4_000);
    };
    void run();
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [mint]);

  // ── live trades ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!mint) return;
    setTrades([]);
    let alive = true;
    let timer: ReturnType<typeof setTimeout>;
    const run = async () => {
      try {
        const res = await fetch(`/api/token-trades?mint=${encodeURIComponent(mint)}`, { cache: "no-store" });
        if (res.ok && alive) {
          const data: { trades?: ApiTrade[] } = await res.json();
          if (alive && Array.isArray(data.trades)) setTrades(data.trades);
        }
      } catch {
        /* keep previous trades */
      }
      if (alive) timer = setTimeout(run, document.hidden ? 30_000 : 10_000);
    };
    void run();
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [mint]);

  // ── holders (Birdeye-backed; optional) ────────────────────────────────
  useEffect(() => {
    if (!mint) return;
    setHolders(null);
    let alive = true;
    const run = async () => {
      try {
        const res = await fetch(`/api/token-holder-count?mint=${encodeURIComponent(mint)}`, { cache: "no-store" });
        if (!res.ok) return;
        const data: { holderCount?: number } = await res.json();
        if (alive && typeof data.holderCount === "number") setHolders(data.holderCount);
      } catch {
        /* optional */
      }
    };
    void run();
    const t = setInterval(run, 60_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [mint]);

  // ── Wraith intel / safety (optional, never blocks the page) ───────────
  const symbolForAnalysis = snap?.symbol ?? selectedMeme?.keyword ?? "";
  const analysisKey = snap ? mint : "";
  useEffect(() => {
    if (!analysisKey) return;
    setAnalysis(null);
    const ctrl = new AbortController();
    const params = new URLSearchParams({
      keyword: symbolForAnalysis,
      contract: mint,
      mcap: String(snap?.marketCap ?? 0),
      liquidity: String(snap?.liquidity ?? 0),
      priceChange1h: String(snap?.priceChange.h1 ?? 0),
    });
    fetch(`/api/analyze?${params.toString()}`, { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((d: Analysis | null) => {
        if (d && !ctrl.signal.aborted) setAnalysis(d);
      })
      .catch(() => undefined);
    return () => ctrl.abort();
    // snap fields are intentionally read once per token; re-running per tick would spam the AI route
  }, [analysisKey]);

  // ── favorites ─────────────────────────────────────────────────────────
  useEffect(() => {
    const sync = () => setSaved(readTokenFavorites().some((f) => f.contractAddress === mint));
    sync();
    window.addEventListener(TOKEN_FAVORITES_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(TOKEN_FAVORITES_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, [mint]);

  // ── price flash on tick ───────────────────────────────────────────────
  const price = snap?.priceUsd ?? null;
  useEffect(() => {
    if (price == null) return;
    const prev = prevPrice.current;
    prevPrice.current = price;
    if (prev != null && prev !== price) setFlash({ dir: price > prev ? "up" : "down", n: Date.now() });
  }, [price]);

  const copy = useCallback((what: "ca" | "link") => {
    const text = what === "ca" ? mint : window.location.href;
    void navigator.clipboard?.writeText(text).then(() => {
      setCopied(what);
      setTimeout(() => setCopied(null), 1600);
    });
  }, [mint]);

  const toggleSave = useCallback(() => {
    if (!mint) return;
    toggleTokenFavorite({
      keyword: snap?.symbol ?? selectedMeme?.keyword ?? mint.slice(0, 4),
      score: 0,
      posts: 0,
      source: "saved",
      contractAddress: mint,
      tokenImageUrl: snap?.imageUrl ?? selectedMeme?.tokenImageUrl,
      mcap: snap?.marketCap ?? selectedMeme?.mcap,
    });
  }, [mint, snap, selectedMeme]);

  const tradeRows: TradeRow[] = useMemo(
    () =>
      trades.map((t) => ({
        ageLabel: fmtAge(t.ts),
        type: t.side === "buy" ? "Buy" : "Sell",
        amountUsd: t.usd,
        tokens: Math.round(t.tokens),
        mcapAtTrade: snap?.supply ? t.priceUsd * snap.supply : 0,
        traderShort: shortAddr(t.wallet, 4, 4),
      })),
    [trades, snap?.supply],
  );

  if (!selectedMeme || !mint) {
    return <div className="wx-empty">Select a token to view its chart.</div>;
  }

  const symbol = snap?.symbol ?? selectedMeme.keyword ?? "TOKEN";
  const name = snap?.name && snap.name !== symbol ? snap.name : null;
  const mcap = snap?.marketCap ?? selectedMeme.mcap ?? null;
  const ch = snap?.priceChange;
  const buys = snap?.txns.h24.buys ?? 0;
  const sells = snap?.txns.h24.sells ?? 0;
  const buyShare = buys + sells > 0 ? (buys / (buys + sells)) * 100 : 50;
  const pumpMint = mint.endsWith("pump");
  const loadingSnap = snapState === "loading" && !snap;

  const stats: { label: string; value: string; sub?: string }[] = [
    { label: "Liquidity", value: fmtUsd(snap?.liquidity) },
    { label: "Volume 24h", value: fmtUsd(snap?.volume.h24 ?? snap?.volume24h), sub: `1h ${fmtUsd(snap?.volume.h1)}` },
    { label: "Holders", value: holders != null ? fmtCount(holders) : "—" },
    { label: "Txns 24h", value: fmtCount(buys + sells), sub: `${fmtCount(buys)} buys · ${fmtCount(sells)} sells` },
    { label: "Age", value: fmtAge(snap?.pairCreatedAt) },
    { label: "Price", value: fmtPrice(snap?.priceUsd) },
  ];

  return (
    <div className="wx-panel">
      {/* ── header ── */}
      <header className="wx-token-head">
        <div className="wx-token-id">
          <TokenIcon contractAddress={mint} imageUrl={snap?.imageUrl ?? selectedMeme.tokenImageUrl ?? undefined} symbol={symbol} size={48} />
          <div style={{ minWidth: 0 }}>
            <div className="wx-token-name">
              <h1>{symbol}</h1>
              {snap?.onCurve && <span className="wx-badge accent">Bonding curve</span>}
              {snap?.graduated && <span className="wx-badge">Graduated</span>}
              {snap?.dexId && !snap.onCurve && <span className="wx-badge muted">{snap.dexId}</span>}
              {snap?.stale && <span className="wx-badge muted">delayed</span>}
            </div>
            <div className="wx-token-sub">
              {name && <span>{name}</span>}
              <button type="button" className="wx-ca" onClick={() => copy("ca")} title="Copy contract address">
                {shortAddr(mint, 5, 5)} {copied === "ca" ? <Check size={11} /> : <Copy size={11} />}
              </button>
            </div>
          </div>
        </div>

        <div className="wx-token-actions">
          {snap?.website && (
            <a href={snap.website} target="_blank" rel="noopener noreferrer" className="wx-icon-btn" aria-label="Website" title="Website">
              <Globe size={14} />
            </a>
          )}
          {snap?.twitter && (
            <a href={snap.twitter} target="_blank" rel="noopener noreferrer" className="wx-icon-btn" aria-label="X / Twitter" title="X / Twitter">
              <XGlyph size={13} />
            </a>
          )}
          {snap?.telegram && (
            <a href={snap.telegram} target="_blank" rel="noopener noreferrer" className="wx-icon-btn" aria-label="Telegram" title="Telegram">
              <Send size={14} />
            </a>
          )}
          <a
            href={pumpMint ? `https://pump.fun/coin/${mint}` : `https://dexscreener.com/solana/${snap?.pairAddress ?? mint}`}
            target="_blank"
            rel="noopener noreferrer"
            className="wx-icon-btn"
            aria-label={pumpMint ? "Open on pump.fun" : "Open on DexScreener"}
            title={pumpMint ? "pump.fun" : "DexScreener"}
          >
            <ExternalLink size={14} />
          </a>
          <button type="button" className="wx-icon-btn" onClick={() => copy("link")} aria-label="Copy page link" title="Copy link">
            {copied === "link" ? <Check size={14} /> : <Link2 size={14} />}
          </button>
          <button type="button" className={`wx-icon-btn${saved ? " active" : ""}`} onClick={toggleSave} aria-pressed={saved} aria-label={saved ? "Remove bookmark" : "Bookmark"} title={saved ? "Saved" : "Save token"}>
            <Bookmark size={14} fill={saved ? "currentColor" : "none"} />
          </button>
        </div>
      </header>

      {/* ── price strip ── */}
      <div className="wx-pricebar">
        <div>
          <div className="wx-kicker">Market cap</div>
          {loadingSnap ? (
            <div className="wx-skel" style={{ width: 150, height: 34 }} />
          ) : (
            <div key={flash?.n ?? 0} className={`wx-mcap${flash ? ` wx-flash-${flash.dir}` : ""}`}>
              {fmtUsd(mcap, { decimals: 2 })}
            </div>
          )}
        </div>
        <div className="wx-changes">
          {(
            [
              ["5m", ch?.m5],
              ["1h", ch?.h1],
              ["6h", ch?.h6],
              ["24h", ch?.h24],
            ] as const
          ).map(([label, v]) => (
            <div key={label} className="wx-change">
              <span>{label}</span>
              <b style={{ color: changeColor(v) }}>{loadingSnap ? "…" : fmtPct(v)}</b>
            </div>
          ))}
        </div>
      </div>

      {snapState === "missing" && !snap && (
        <div className="wx-note">
          No market found for this mint yet. It may be brand new or not indexed — the page keeps checking automatically.
        </div>
      )}
      {snapState === "error" && !snap && <div className="wx-note warn">Market data is slow to respond. Retrying…</div>}

      {/* ── chart ── */}
      <section className="wx-chart-card" aria-label="Price chart">
        <TokenChart mint={mint} livePrice={snap?.priceUsd ?? null} supply={snap?.supply ?? null} />
      </section>

      {/* ── bonding curve ── */}
      {snap?.onCurve && snap.curveProgress != null && (
        <div className="wx-curve">
          <div className="wx-curve-head">
            <span>Bonding curve progress</span>
            <b>~{Math.round(snap.curveProgress * 100)}%</b>
          </div>
          <div className="wx-bar">
            <i style={{ width: `${Math.max(2, snap.curveProgress * 100)}%` }} />
          </div>
          <small>Estimate based on market cap. Graduates to a DEX pool when the curve completes.</small>
        </div>
      )}

      {/* ── stats ── */}
      <div className="wx-stats">
        {stats.map((s) => (
          <div key={s.label} className="wx-stat">
            <span>{s.label}</span>
            {loadingSnap ? <div className="wx-skel" style={{ width: "70%", height: 16 }} /> : <b>{s.value}</b>}
            {s.sub && !loadingSnap && <small>{s.sub}</small>}
          </div>
        ))}
        <div className="wx-stat wide">
          <span>Buy / sell pressure (24h)</span>
          <div className="wx-pressure">
            <i style={{ width: `${buyShare}%` }} />
          </div>
          <small>
            <b style={{ color: "var(--win)" }}>{buyShare.toFixed(0)}% buys</b> · <b style={{ color: "var(--loss)" }}>{(100 - buyShare).toFixed(0)}% sells</b>
          </small>
        </div>
      </div>

      {/* ── safety ── */}
      {analysis?.safetyBreakdown && analysis.safetyBreakdown.length > 0 && (
        <section className="wx-safety">
          <div className="wx-safety-head">
            <strong>Risk checks</strong>
            {typeof analysis.safetyScore === "number" && <span>{analysis.safetyScore}/100</span>}
          </div>
          <div className="wx-safety-grid">
            {analysis.safetyBreakdown.map((c) => (
              <div key={c.label} className={c.pass ? "ok" : "bad"} title={c.detail}>
                <b>{c.pass ? "✓" : "✕"}</b> {c.label}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ── activity ── */}
      <div style={{ padding: "0 0 20px" }}>
        <TokenDetailTabs trades={tradeRows} mint={mint} intelLinks={analysis?.links} intelSummary={analysis?.predictionReason} />
      </div>
    </div>
  );
}
