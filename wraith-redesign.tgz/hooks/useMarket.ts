"use client";

// hooks/useMarket.ts
// Polls /api/market for one category. Keeps the previous list on screen while
// refreshing or when a refresh fails (a flaky provider never blanks the board).

import { useCallback, useEffect, useRef, useState } from "react";
import type { MarketCategory, MarketToken } from "@/lib/market";

export interface UseMarket {
  tokens: MarketToken[];
  loading: boolean;
  error: string | null;
  stale: boolean;
  updatedAt: number | null;
  refresh: () => void;
}

export function useMarket(category: MarketCategory, intervalMs = 25_000): UseMarket {
  const [tokens, setTokens] = useState<MarketToken[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stale, setStale] = useState(false);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);
  const reqId = useRef(0);
  const hasData = useRef(false);

  const load = useCallback(async () => {
    const id = ++reqId.current;
    try {
      const res = await fetch(`/api/market?category=${category}`, {
        cache: "no-store",
        signal: AbortSignal.timeout(25_000),
      });
      if (id !== reqId.current) return;
      const data: { tokens?: MarketToken[]; stale?: boolean; updatedAt?: number; error?: string } = await res.json().catch(() => ({}));
      if (id !== reqId.current) return;
      if (res.ok && Array.isArray(data.tokens)) {
        setTokens(data.tokens);
        setStale(Boolean(data.stale));
        setUpdatedAt(data.updatedAt ?? Date.now());
        setError(null);
        hasData.current = true;
      } else if (!hasData.current) {
        setError(data.error ?? "Couldn't load tokens.");
      } else {
        setStale(true);
      }
    } catch {
      if (id === reqId.current && !hasData.current) setError("Couldn't reach the server.");
      else if (id === reqId.current) setStale(true);
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  }, [category]);

  useEffect(() => {
    hasData.current = false;
    setTokens([]);
    setLoading(true);
    setError(null);
    setStale(false);
    void load();
    const t = setInterval(() => {
      if (!document.hidden) void load();
    }, intervalMs);
    return () => {
      reqId.current++;
      clearInterval(t);
    };
  }, [load, intervalMs]);

  return { tokens, loading, error, stale, updatedAt, refresh: () => void load() };
}
