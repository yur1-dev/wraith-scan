"use client";

// components/TokenChart.tsx
// Pump.fun / Fomo style chart: candles or orange area, volume histogram,
// MCap/Price toggle, live tick merged into the current candle, proper
// loading / empty / error states. Data comes from /api/token-chart.

import { useCallback, useEffect, useRef, useState } from "react";
import {
  AreaSeries,
  CandlestickSeries,
  ColorType,
  CrosshairMode,
  HistogramSeries,
  createChart,
  type IChartApi,
  type ISeriesApi,
  type MouseEventParams,
  type Time,
  type UTCTimestamp,
} from "lightweight-charts";
import { RefreshCw } from "lucide-react";
import { fmtPct, fmtPrice, fmtUsd } from "@/lib/market";

export interface ChartCandle {
  t: number; // bucket start, ms
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
}

const TIMEFRAMES = [
  { key: "1m", label: "1m", sec: 60 },
  { key: "5m", label: "5m", sec: 300 },
  { key: "15m", label: "15m", sec: 900 },
  { key: "1h", label: "1h", sec: 3600 },
  { key: "4h", label: "4h", sec: 14400 },
  { key: "1d", label: "1D", sec: 86400 },
] as const;
type TfKey = (typeof TIMEFRAMES)[number]["key"];
type Metric = "mcap" | "price";
type Style = "candles" | "line";

const ACCENT = "#ff7b3d";
const UP = "#22c55e";
const DOWN = "#ef4444";
const POLL_MS = 15_000;
const EMPTY_POLL_MS = 5_000;

function readPref<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v && (allowed as readonly string[]).includes(v) ? (v as T) : fallback;
  } catch {
    return fallback;
  }
}
function writePref(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* storage unavailable */
  }
}

// lightweight-charts renders UTC; shift into the viewer's local time.
function chartTime(tMs: number): UTCTimestamp {
  return (tMs / 1000 - new Date(tMs).getTimezoneOffset() * 60) as UTCTimestamp;
}

type Status = "loading" | "ready" | "empty" | "error";

export default function TokenChart({
  mint,
  livePrice,
  supply,
}: {
  mint: string;
  /** latest spot price in USD, merged into the current candle */
  livePrice?: number | null;
  /** circulating supply (mcap / price) — enables the MCap view */
  supply?: number | null;
}) {
  const [tf, setTf] = useState<TfKey>("15m");
  const [metric, setMetric] = useState<Metric>("mcap");
  const [style, setStyle] = useState<Style>("candles");
  const [status, setStatus] = useState<Status>("loading");
  const [candles, setCandles] = useState<ChartCandle[]>([]);
  const [source, setSource] = useState<string>("");
  const [stale, setStale] = useState(false);
  const [legend, setLegend] = useState<ChartCandle | null>(null);

  const hostRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const mainRef = useRef<ISeriesApi<"Candlestick"> | ISeriesApi<"Area"> | null>(null);
  const volRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const candlesRef = useRef<ChartCandle[]>([]);
  const needFitRef = useRef(true);
  const reqRef = useRef(0);
  const lastTickRef = useRef<number>(0);

  const supplyKey = supply && supply > 0 ? Math.round(supply) : 0;
  const effectiveMetric: Metric = metric === "mcap" && supplyKey ? "mcap" : "price";
  const mult = effectiveMetric === "mcap" ? supplyKey : 1;
  const tfSec = TIMEFRAMES.find((x) => x.key === tf)?.sec ?? 900;

  // ── persisted prefs (after mount: avoids hydration mismatch) ───────────
  useEffect(() => {
    setTf(readPref("wraith_chart_tf", TIMEFRAMES.map((x) => x.key), "15m"));
    setMetric(readPref("wraith_chart_metric", ["mcap", "price"] as const, "mcap"));
    setStyle(readPref("wraith_chart_style", ["candles", "line"] as const, "candles"));
  }, []);

  // ── create chart once ──────────────────────────────────────────────────
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const chart = createChart(host, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#8b8b92",
        fontFamily: "var(--font-mono), 'IBM Plex Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "rgba(255,255,255,0.03)" },
        horzLines: { color: "rgba(255,255,255,0.045)" },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { color: "rgba(255,123,61,0.45)", labelBackgroundColor: ACCENT },
        horzLine: { color: "rgba(255,123,61,0.45)", labelBackgroundColor: ACCENT },
      },
      rightPriceScale: {
        borderColor: "rgba(255,255,255,0.08)",
        scaleMargins: { top: 0.08, bottom: 0.24 },
      },
      timeScale: {
        borderColor: "rgba(255,255,255,0.08)",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 6,
        barSpacing: 9,
        minBarSpacing: 2,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });
    chartRef.current = chart;

    const onMove = (param: MouseEventParams<Time>) => {
      if (!param.time || !mainRef.current) {
        setLegend(null);
        return;
      }
      const data = param.seriesData.get(mainRef.current) as
        | { open?: number; high?: number; low?: number; close?: number; value?: number }
        | undefined;
      const vol = volRef.current ? (param.seriesData.get(volRef.current) as { value?: number } | undefined) : undefined;
      if (!data) {
        setLegend(null);
        return;
      }
      const m = metricMultRef.current;
      const c = (data.close ?? data.value ?? 0) / m;
      setLegend({
        t: 0,
        o: (data.open ?? data.value ?? 0) / m,
        h: (data.high ?? data.value ?? 0) / m,
        l: (data.low ?? data.value ?? 0) / m,
        c,
        v: vol?.value ?? 0,
      });
    };
    chart.subscribeCrosshairMove(onMove);

    return () => {
      chart.unsubscribeCrosshairMove(onMove);
      chart.remove();
      chartRef.current = null;
      mainRef.current = null;
      volRef.current = null;
    };
  }, []);

  // crosshair handler needs the current multiplier without re-subscribing
  const metricMultRef = useRef(1);
  metricMultRef.current = mult;

  // ── (re)build series when style / metric changes ──────────────────────
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    if (mainRef.current) chart.removeSeries(mainRef.current);
    if (volRef.current) chart.removeSeries(volRef.current);

    const formatter = effectiveMetric === "mcap" ? (p: number) => fmtUsd(p, { decimals: 2 }).replace("—", "$0") : (p: number) => fmtPrice(p);
    const priceFormat = {
      type: "custom" as const,
      minMove: effectiveMetric === "mcap" ? 1 : 1e-12,
      formatter,
    };

    mainRef.current =
      style === "candles"
        ? chart.addSeries(CandlestickSeries, {
            upColor: UP,
            downColor: DOWN,
            borderUpColor: UP,
            borderDownColor: DOWN,
            wickUpColor: UP,
            wickDownColor: DOWN,
            priceFormat,
            priceLineColor: ACCENT,
          })
        : chart.addSeries(AreaSeries, {
            lineColor: ACCENT,
            topColor: "rgba(255,123,61,0.28)",
            bottomColor: "rgba(255,123,61,0.0)",
            lineWidth: 2,
            priceFormat,
            priceLineColor: ACCENT,
          });

    volRef.current = chart.addSeries(HistogramSeries, {
      priceFormat: { type: "volume" },
      priceScaleId: "",
      lastValueVisible: false,
      priceLineVisible: false,
    });
    volRef.current.priceScale().applyOptions({ scaleMargins: { top: 0.84, bottom: 0 } });
    needFitRef.current = true;
  }, [style, effectiveMetric]);

  // ── push candles into series ──────────────────────────────────────────
  useEffect(() => {
    const main = mainRef.current;
    const vol = volRef.current;
    const chart = chartRef.current;
    if (!main || !vol || !chart) return;

    candlesRef.current = candles.map((c) => ({ ...c }));
    if (!candles.length) {
      main.setData([]);
      vol.setData([]);
      return;
    }

    const seen = new Set<number>();
    const mainData: unknown[] = [];
    const volData: { time: UTCTimestamp; value: number; color: string }[] = [];
    for (const c of candles) {
      const time = chartTime(c.t);
      if (seen.has(time)) continue;
      seen.add(time);
      if (style === "candles") {
        mainData.push({ time, open: c.o * mult, high: c.h * mult, low: c.l * mult, close: c.c * mult });
      } else {
        mainData.push({ time, value: c.c * mult });
      }
      volData.push({ time, value: c.v, color: c.c >= c.o ? "rgba(34,197,94,0.38)" : "rgba(239,68,68,0.38)" });
    }
    (main as ISeriesApi<"Candlestick">).setData(mainData as never);
    vol.setData(volData);

    if (needFitRef.current) {
      needFitRef.current = false;
      const n = mainData.length;
      if (n > 90) chart.timeScale().setVisibleLogicalRange({ from: n - 90, to: n + 6 });
      else chart.timeScale().fitContent();
    }
  }, [candles, style, mult]);

  // ── merge live price into the running candle ──────────────────────────
  useEffect(() => {
    const main = mainRef.current;
    const list = candlesRef.current;
    if (!main || !livePrice || !(livePrice > 0) || !list.length) return;
    if (livePrice === lastTickRef.current) return;
    lastTickRef.current = livePrice;

    const step = tfSec * 1000;
    const bucket = Math.floor(Date.now() / step) * step;
    let last = list[list.length - 1];
    // Ignore ticks wildly off the series (stale provider glitch).
    if (livePrice > last.c * 20 || livePrice < last.c / 20) return;

    if (last.t < bucket) {
      const next: ChartCandle = { t: bucket, o: last.c, h: Math.max(last.c, livePrice), l: Math.min(last.c, livePrice), c: livePrice, v: 0 };
      list.push(next);
      last = next;
    } else {
      last.c = livePrice;
      last.h = Math.max(last.h, livePrice);
      last.l = Math.min(last.l, livePrice);
    }
    const time = chartTime(last.t);
    if (style === "candles") {
      (main as ISeriesApi<"Candlestick">).update({
        time,
        open: last.o * mult,
        high: last.h * mult,
        low: last.l * mult,
        close: last.c * mult,
      });
    } else {
      (main as ISeriesApi<"Area">).update({ time, value: last.c * mult });
    }
  }, [livePrice, style, mult, tfSec]);

  // ── fetch + poll ──────────────────────────────────────────────────────
  const load = useCallback(
    async (initial: boolean) => {
      const id = ++reqRef.current;
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 25_000);
      try {
        const res = await fetch(`/api/token-chart?address=${encodeURIComponent(mint)}&tf=${tf}`, {
          signal: ctrl.signal,
          cache: "no-store",
        });
        if (id !== reqRef.current) return;
        if (!res.ok) throw new Error(String(res.status));
        const data: { candles?: ChartCandle[]; source?: string; stale?: boolean } = await res.json();
        if (id !== reqRef.current) return;
        const rows = Array.isArray(data.candles) ? data.candles : [];
        setSource(data.source ?? "");
        setStale(Boolean(data.stale));
        if (rows.length) {
          setCandles(rows);
          setStatus("ready");
        } else if (initial || candlesRef.current.length === 0) {
          setCandles([]);
          setStatus("empty");
        }
      } catch {
        if (id !== reqRef.current) return;
        if (candlesRef.current.length === 0) setStatus("error");
      } finally {
        clearTimeout(timer);
      }
    },
    [mint, tf],
  );

  const statusRef = useRef<Status>("loading");
  statusRef.current = status;

  useEffect(() => {
    needFitRef.current = true;
    candlesRef.current = [];
    lastTickRef.current = 0;
    setCandles([]);
    setStatus("loading");
    setLegend(null);
    void load(true);

    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      timer = setTimeout(
        () => {
          if (!document.hidden) void load(false);
          tick();
        },
        statusRef.current === "ready" ? POLL_MS : EMPTY_POLL_MS,
      );
    };
    tick();
    return () => {
      reqRef.current++;
      clearTimeout(timer);
    };
  }, [load]);

  const last = candles[candles.length - 1];
  const shown = legend ?? last ?? null;
  const first = candles[0];
  const rangeChange = first && last ? ((last.c - first.o) / first.o) * 100 : null;
  const fmtVal = (n: number) => (effectiveMetric === "mcap" ? fmtUsd(n * mult, { decimals: 2 }) : fmtPrice(n));

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", minHeight: 0 }}>
      {/* toolbar */}
      <div className="wx-chart-toolbar">
        <div className="wx-seg" role="tablist" aria-label="Timeframe">
          {TIMEFRAMES.map((x) => (
            <button
              key={x.key}
              type="button"
              role="tab"
              aria-selected={tf === x.key}
              className={tf === x.key ? "on" : ""}
              onClick={() => {
                setTf(x.key);
                writePref("wraith_chart_tf", x.key);
              }}
            >
              {x.label}
            </button>
          ))}
        </div>
        <div style={{ flex: 1 }} />
        <div className="wx-seg" aria-label="Chart value">
          {(["mcap", "price"] as const).map((m) => (
            <button
              key={m}
              type="button"
              className={effectiveMetric === m ? "on" : ""}
              disabled={m === "mcap" && !supplyKey}
              title={m === "mcap" && !supplyKey ? "Market cap unavailable for this token" : undefined}
              onClick={() => {
                setMetric(m);
                writePref("wraith_chart_metric", m);
              }}
            >
              {m === "mcap" ? "MCap" : "Price"}
            </button>
          ))}
        </div>
        <div className="wx-seg" aria-label="Chart style">
          {(["candles", "line"] as const).map((s) => (
            <button
              key={s}
              type="button"
              className={style === s ? "on" : ""}
              onClick={() => {
                setStyle(s);
                writePref("wraith_chart_style", s);
              }}
            >
              {s === "candles" ? "Candles" : "Line"}
            </button>
          ))}
        </div>
        <button type="button" className="wx-icon-btn" onClick={() => void load(true)} aria-label="Refresh chart" title="Refresh">
          <RefreshCw size={13} />
        </button>
      </div>

      {/* OHLC legend */}
      <div className="wx-legend">
        {shown ? (
          <>
            <span>O <b>{fmtVal(shown.o)}</b></span>
            <span>H <b>{fmtVal(shown.h)}</b></span>
            <span>L <b>{fmtVal(shown.l)}</b></span>
            <span>C <b style={{ color: shown.c >= shown.o ? UP : DOWN }}>{fmtVal(shown.c)}</b></span>
            {shown.v > 0 && <span>Vol <b>{fmtUsd(shown.v)}</b></span>}
            {rangeChange !== null && !legend && (
              <span style={{ color: rangeChange >= 0 ? UP : DOWN }}>{fmtPct(rangeChange)}</span>
            )}
          </>
        ) : (
          <span style={{ opacity: 0.6 }}>—</span>
        )}
        <span style={{ flex: 1 }} />
        {source && (
          <span className="wx-src" title={stale ? "Showing last known data; provider is slow" : `Source: ${source}`}>
            {stale ? "stale · " : ""}
            {source.replace("geckoterminal", "gecko").replace("pumpfun-onchain", "on-chain")}
          </span>
        )}
      </div>

      {/* chart surface */}
      <div style={{ position: "relative", flex: 1, minHeight: 260 }}>
        <div ref={hostRef} style={{ position: "absolute", inset: 0 }} />

        {status === "loading" && (
          <div className="wx-chart-overlay">
            <div className="wx-skel" style={{ width: "100%", height: "100%", borderRadius: 0, opacity: 0.55 }} />
            <span className="wx-chart-msg">Loading chart…</span>
          </div>
        )}
        {status === "empty" && (
          <div className="wx-chart-overlay">
            <div className="wx-chart-msg-box">
              <strong>No candles yet</strong>
              <span>Checking for first trades — this retries automatically.</span>
              <button type="button" className="wx-btn" onClick={() => void load(true)}>
                <RefreshCw size={12} /> Retry now
              </button>
            </div>
          </div>
        )}
        {status === "error" && (
          <div className="wx-chart-overlay">
            <div className="wx-chart-msg-box">
              <strong>Couldn&apos;t load the chart</strong>
              <span>The data providers didn&apos;t respond. Try again in a moment.</span>
              <button type="button" className="wx-btn" onClick={() => void load(true)}>
                <RefreshCw size={12} /> Retry
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
